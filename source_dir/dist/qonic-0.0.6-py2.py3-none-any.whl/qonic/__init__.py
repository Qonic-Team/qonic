from .ConstraintSatisfaction.ConstraintSatisfaction import ConstraintSatisfactionProblem
from .QProgram.QProgram import QProgram

__version__ = '0.0.6'
